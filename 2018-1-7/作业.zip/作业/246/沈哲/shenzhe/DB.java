package com.bdqn.yd3.shenzhe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
	private final String NAME="root";//�û���
	private final String PWD="root";//����
	private final String URL="jdbc:mysql://localhost:3306/student";
	private	final String DRIVER="com.mysql.jdbc.Driver";
	
	public Connection db() {//��������
		Connection con=null;
	try {
		Class.forName(DRIVER);
		con=DriverManager.getConnection(URL, NAME, PWD);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con;
	}
	public static void free(ResultSet rs,Statement stmt,Connection conn){
		
			try {
				if(rs !=null)
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
					try {
						if(stmt !=null)
						stmt.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}finally{
							try {
								if(conn !=null)
								conn.close();
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					
					}
				
			}
			
	}
		
}



