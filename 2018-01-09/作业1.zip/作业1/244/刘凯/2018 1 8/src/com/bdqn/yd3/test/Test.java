package com.bdqn.yd3.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.yd3.bean.Bean;
import com.bdqn.yd3.jdbc.Jdbc;

/**
 * 
 * @author����
 *
 * 2018��1��8������10:05:19
 */
public class Test {
	Jdbc j=new Jdbc();
	Connection con=j.jdbc();
	public int add(Bean b){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {

			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,b.getEname() );
			ps.setString(2, b.getEsex());
			ps.setString(3, b.getBir());
			ps.setInt(4, b.getPhone());
			ps.setDouble(5, b.getMoney());
			ps.setString(6, b.getAddress());
			i=ps.executeUpdate();
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		




	}





}


