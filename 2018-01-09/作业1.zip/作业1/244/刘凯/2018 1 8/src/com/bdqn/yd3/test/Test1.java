package com.bdqn.yd3.test;


import com.bdqn.yd3.bean.Bean;

public class Test1 {

	public static void main(String[] args) {
		Bean b=new Bean();
		Test t=new Test();
		b.setEname("����");
		b.setEsex("��");
		b.setBir("1980.12.02");
		b.setPhone(123456);
		b.setMoney(1688);
		b.setAddress("M78���ƹ�֮��");
		t.add(b);
		
	}

}
