package com.bdqn.yd3.zxx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Don {
	Todb t=new Todb();
	Connection con=t.todb();
	public int add(Diy todb){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,todb.getEname());
			ps.setString(2, todb.getEsex());
			ps.setString(3, todb.getBir());
			ps.setInt(4, todb.getPhone());
			ps.setDouble(5, todb.getMoney());
			ps.setString(6, todb.getAddress());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return i;
	}
	
}
