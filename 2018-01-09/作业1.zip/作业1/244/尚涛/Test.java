package com.bdqn.yd3.zxx;

public class Test {
	public static void main(String[] args) {
		Diy d=new Diy();
		Don o=new Don();
		d.setEname("�վ����");
		d.setEsex("��");
		d.setBir("1966.06");
		d.setPhone(5788644);
		d.setMoney(15000);
		d.setAddress("����");
		o.add(d);
		
		
	}

	
	
}
