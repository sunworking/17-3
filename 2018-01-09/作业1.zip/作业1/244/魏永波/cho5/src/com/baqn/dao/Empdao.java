package com.baqn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.baqn.util.Todb;

/**
 * 
 * @author κ����
 *
 * 2018��1��9������1:56:14
 */
public class Empdao {
	Todb t=new Todb();
	Connection con=t.a();	
	public int add(Myfeng a){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, a.getEname());
			ps.setString(2, a.getEsex());
			ps.setString(3, a.getBir());
			ps.setInt(4, a.getPhone());
			ps.setDouble(5, a.getMoney());
			ps.setString(6, a.getAddress());			
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return i;		
	}
}
