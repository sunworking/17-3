package xml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestDemo {
	JDBCFramr t=new JDBCFramr();
	Connection con=t.todb();
	Util u=new Util();
	public int add(Util util){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, u.getEname());
			ps.setString(2, u.getEsex());
			ps.setString(3, u.getBir());
			ps.setString(4, u.getMoney());
			ps.setString(5, u.getMoney());
			ps.setString(6, u.getAddress());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
		
	}
	
}