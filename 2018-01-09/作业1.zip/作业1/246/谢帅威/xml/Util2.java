package xml;

public class Util2 {
	public static void main(String[] args) {
		Util a=new Util();
		TestDemo t=new TestDemo();
		a.setEname("����");
		a.setEsex("��");
		a.setBir("18");
		a.setPhone(135131);
		a.setMoney("4100");
		a.setAddress("����");
		if (t.add(a)==1) {
			System.out.println("asa");
		} else {
			System.out.println("asa");
		}
	}
}
