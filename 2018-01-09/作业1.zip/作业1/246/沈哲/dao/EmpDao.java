package com.bdqn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.util.DB;
import com.bdqn.bean.Emp;
/**
 * 
 * @author ����
 *
 * 2018��1��8������10:21:22
 */
public class EmpDao {
	Emp e=new Emp();
	DB d=new DB();
	Connection con=d.db();
	public int add(Emp emp){
		int i=1;
		String sql="insert into emp values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,emp.getEno());
			ps.setString(2, emp.getEname());
			ps.setString(3, emp.getEsex());
			ps.setString(4, emp.getBir());
			ps.setInt(5, emp.getPhone());
			ps.setDouble(6, emp.getMoney());
			ps.setString(7, emp.getAddress());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	public int del(int eno){
		int i=1;
		String sql="delete from emp where eno="+eno;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	public int update(Emp emp){
		int i=1;
		String sql="update emp set ename=?,esex=?,bir=?,phone=?,money=?,address=? where eno=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, emp.getEname());
			ps.setString(2, emp.getEsex());
			ps.setString(3, emp.getBir());
			ps.setInt(4, emp.getPhone());
			ps.setDouble(5, emp.getMoney());
			ps.setString(6, emp.getAddress());
			ps.setInt(7,emp.getEno());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	

}
