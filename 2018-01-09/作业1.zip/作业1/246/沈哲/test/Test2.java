package com.bdqn.test;

import java.sql.Connection;

import com.bdqn.dao.EmpDao;
import com.bdqn.util.DB;

/**
 * 
 * @author ����
 *ɾ
 * 2018��1��8������9:40:38
 */
public class Test2 {
	public static void main(String[] args) {
		EmpDao ed=new EmpDao();
		ed.del(2);
		
		
		
		
		
	}
	
	

}
