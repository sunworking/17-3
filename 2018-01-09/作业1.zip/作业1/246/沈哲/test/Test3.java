package com.bdqn.test;

import com.bdqn.bean.Emp;
import com.bdqn.dao.EmpDao;

public class Test3 {
	public static void main(String[] args) {
		EmpDao ed=new EmpDao();
		Emp e=new Emp();
		e.setEno(2);
		e.setEname("����");
		e.setEsex("��");
		e.setBir("1998.6.8");
		e.setPhone(1319345);
		e.setMoney(3000.00);
		e.setAddress("��������");
		ed.update(e);
	}

}
