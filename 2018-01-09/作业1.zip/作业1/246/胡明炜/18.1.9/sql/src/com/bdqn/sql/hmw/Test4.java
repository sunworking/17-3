package com.bdqn.sql.hmw;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * ��
 * @author �����
 *2018��1��7������1:45:15
 */
public class Test4 {
	public static void main(String[] args) {
		Todb t=new Todb();
		
		try {
			Connection con=t.todb();//��������
			Statement stmt=con.createStatement();//��ȡStatement����
			String sql="select*from stu";//
			stmt.execute(sql);
			free(null,stmt,con);
			System.out.println();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��ȡStatement����


	}

	private static void free(Object object, Statement stmt, Connection con) {
		// TODO Auto-generated method stub
		
	}

}
