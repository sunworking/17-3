package com.bdqn.sql.hmw;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.spi.DirStateFactory.Result;


/**
 * 
 * @author �����
 *2018��1��6������11:46:37
 */
public class Todb {
	private final String NAME="root";//�û���
	private final String PWD="root";//����
	private final String URL="jdbc:mysql://localhost:3306/student";
	private final String DRIVER="com.mysql.jdbc.Driver";
	public Connection todb(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(URL, NAME, PWD);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
}
