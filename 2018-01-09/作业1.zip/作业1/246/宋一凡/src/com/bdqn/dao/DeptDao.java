package com.bdqn.dao;

import java.sql.Connection;

import com.bdqn.util.Todb;

/**
 * 
 * @author ��һ��
 *
 * 2018��1��8������9:21:55
 */
public class DeptDao {
	Todb t=new Todb();
	Connection con=t.todb();
	public void add(){
		
	}
	public void delete(){
		
	}
	public void update(){
		
	}
}
