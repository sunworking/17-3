package com.bdqn.dao;
/**
 * 
 * @author ��һ��
 *
 * 2018��1��8������9:04:00
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.util.Todb;

public class EmpDao {
	Todb t=new Todb();
	Connection con=t.todb();
	public int add(){
		int i=0;
		String sql="insert into student values(sid,'����',18,'��')";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	
	}
