package com.bdqn.syf;

public class Dept {
	private int dno;
	private String dname;
	private String leader;
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLeader() {
		return leader;
	}
	public void setLeader(String leader) {
		this.leader = leader;
	}
	public void delete(){
		
	}
	public void update(){
		
	}
}
