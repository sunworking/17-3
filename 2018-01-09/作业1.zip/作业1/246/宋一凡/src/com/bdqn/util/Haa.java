package com.bdqn.yd3.zzw;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * 
 * @author ��һ��
 *
 *2018��1��9������1:10:26
 */
public class Haa {
	Tab t=new Tab();
	Connection con=t.tab();
	public int add(Ha tab){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,tab.getEname());
			ps.setString(2, tab.getEsex());
			ps.setString(3, tab.getBir());
			ps.setString(4, tab.getPhone());
			ps.setDouble(5, tab.getMoney());
			ps.setString(6, tab.getAddress());
			i=ps.executeUpdate();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
	}

}
