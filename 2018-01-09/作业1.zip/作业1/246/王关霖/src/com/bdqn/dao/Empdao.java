package com.bdqn.dao;

public class Empdao {

	
}
}
