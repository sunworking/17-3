package com.bdqn.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Asd {
Asdf a=new Asdf();
Connection con =a.llllll();
int i=0;
public int asdfg(){
	String sql="insert into emp values(eno,?,?,?,?, ?,?)";
	try {
		PreparedStatement ps=	con.prepareStatement(sql);
		ps.setString(1, "����");
		ps.setString(2, "��");
		ps.setString(3, "1920/01/28");
		ps.setString(4, "1360518455474");
		ps.setDouble(5, 5000);
		ps.setString(6, "����ʡ֣����");
		i=ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	public int fghkhjg(){
		String sql="insert into emp values(eno,?,?,?,?, ?,?)where";
		try {
			PreparedStatement ps=	con.prepareStatement(sql);
			ps.setString(1, "����");
			ps.setString(2, "��");
			ps.setString(3, "1920/01/28");
			ps.setString(4, "1360518455474");
			ps.setDouble(5, 5000);
			ps.setString(6, "����ʡ֣����");
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	
	
	return i;
	
}
}
