package com.bdqn.lib;

public class Emp {
	private int gonghao;
	private String name;
	private String xing;
	private String nian;
	private String dian;
	private int gong;
	private String dizhi;
	public int getGonghao() {
		return gonghao;
	}
	public void setGonghao(int gonghao) {
		this.gonghao = gonghao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getXing() {
		return xing;
	}
	public void setXing(String xing) {
		this.xing = xing;
	}
	public String getNian() {
		return nian;
	}
	public void setNian(String nian) {
		this.nian = nian;
	}
	public String getDian() {
		return dian;
	}
	public void setDian(String dian) {
		this.dian = dian;
	}
	public int getGong() {
		return gong;
	}
	public void setGong(int gong) {
		this.gong = gong;
	}
	public String getDizhi() {
		return dizhi;
	}
	public void setDizhi(String dizhi) {
		this.dizhi = dizhi;
	}
	
}
