package com.bdqn.ceshi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.bean.Lei_1;
import com.bdqn.lib.Emp;

public class Ceshi_1 {
	Lei_1 l=new Lei_1();
	Connection con=l.Lei_0();
	Emp emp=new Emp();
	int a=emp.getGonghao();
	String b=emp.getName();
	String c=emp.getXing();
	String d=emp.getNian();
	String e=emp.getDian();
	int f=emp.getGong();
	String g=emp.getDizhi();
	public void zeng(){
		String sql="insert into emp values (?,?,?,?,?,?,?);";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,a);
			ps.setString(2,b);
			ps.setString(3,c);
			ps.setString(4,d);
			ps.setString(5,e);
			ps.setInt(6,f);
			ps.setString(7,g);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
