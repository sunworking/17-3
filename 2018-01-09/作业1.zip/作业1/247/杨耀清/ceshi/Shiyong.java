package com.bdqn.ceshi;

import com.bdqn.lib.Emp;

public class Shiyong {
	public static void main(String[] args) {
		Ceshi_1 cs=new Ceshi_1();
		Emp emp=new Emp();
		emp.setGonghao(1);
		emp.setName("����");
		emp.setXing("��");
		emp.setNian("1988-12");
		emp.setDian("123");
		emp.setGong(4281);
		emp.setDizhi("������");
		cs.zeng();
	}
}
