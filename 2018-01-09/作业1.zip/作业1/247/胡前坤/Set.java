/**
 * 
 */
package com.bdqn.sdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author ��ǰ��
 *
 * 2018��1��8������8:40:39
 */
public class Set {
		private final String NAME="root";
		String PWD="root";
		String URL="jdbc:mysql://localhost:33061Student";
		String DRIVER="com.mysql.jdbc.Driver";
		
		public void todb(){
			Connection con=null;
			try {
				Class.forName(DRIVER);
				con=DriverManager.getConnection(URL,NAME,PWD);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		/**
		 * @return
		 */
		public Connection set() {
			// TODO Auto-generated method stub
			return null;
		}

