/**
 * 
 */
package com.bdqn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.sdb.Set;
import com.bdqn.text.T_te;

/**
 * @author ��ǰ��
 *
 * 2018��1��8������10:55:47
 */
public class StudentDao {
	Set se=new Set();
	Connection con= se.set();
	T_te tt=new T_te();
	public int add(){
		int i=1;
		String sql="insert into student values(ename,'����',)";
		try {
			PreparedStatement pr=con.prepareStatement(null);
			i=pr.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int adb(){
		int i=1;
		String sql="update student set S_class=��S_class�� where esex=ase ;"
		try {
			PreparedStatement pr=con.prepareStatement(null);
			i=pr.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int adc(){
		int i=1;
		String sql="delecte from student where ename='asd";
		try {
			PreparedStatement pr=con.prepareStatement(null);
			i=pr.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	/**
	 * @return
	 */
	public int update() {
		// TODO Auto-generated method stub
		return 0;
	}
}
