package com.bdqn.wyk3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.wyk.Yu;
import com.bdqn.wyk2.Tu;

public class Ru {
	Tu j=new Tu();
	Connection con=j.jdbc();
	public int add(Yu b){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {

			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,b.getEname() );
			ps.setString(2, b.getEsex());
			ps.setString(3, b.getBir());
			ps.setInt(4, b.getPhone());
			ps.setDouble(5, b.getMoney());
			ps.setString(6, b.getAddress());
			i=ps.executeUpdate();
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		




	}





}

