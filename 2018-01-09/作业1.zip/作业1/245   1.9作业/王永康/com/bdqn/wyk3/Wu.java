package com.bdqn.wyk3;

import com.bdqn.wyk.Yu;

public class Wu {
	public static void main(String[] args) {
		Yu b=new Yu();
		Ru r=new Ru();
		b.setEname("����");
		b.setEsex("��");
		b.setBir("1980.12.02");
		b.setPhone(123456);
		b.setMoney(1688);
		b.setAddress("85225");
		r.add(b);
		
	}
}
