package com.bdqn.doan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;




//��
public class Jdbc_3 {
	Todb t=new Todb();
	Connection con=t.todb();
	Jdbc_2 j2=new Jdbc_2();
	public int add(Jdbc_2 j2){
		int i=0;
		String sql="insert into emp values(sid,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(0, j2.getAddres());
			ps.setString(1, j2.getBir());
			ps.setString(2, j2.getEname());
			ps.setString(3, j2.getMoney());
			ps.setInt(4, j2.getEno());
			ps.setInt(5, j2.getPhone());
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	
}

//ɾ
public int shan(Jdbc_2 j2){
	int i=0;
	String sql="delete from emp where(sid,?,?,?,?,?)";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(0, j2.getAddres());
		ps.setString(1, j2.getBir());
		ps.setString(2, j2.getEname());
		ps.setString(3, j2.getMoney());
		ps.setInt(4, j2.getEno());
		ps.setInt(5, j2.getPhone());
	} catch (SQLException e) {
		
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return i;
}
}

//��
public int gai(Jdbc_2 j2){
	int i=0;
	String sql="update emp set sid=(sid,?,?,?,?,?)";
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(0, j2.getAddres());
		ps.setString(1, j2.getBir());
		ps.setString(2, j2.getEname());
		ps.setString(3, j2.getMoney());
		ps.setInt(4, j2.getEno());
		ps.setInt(5, j2.getPhone());
	} catch (SQLException e) {
		
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return i;
}

