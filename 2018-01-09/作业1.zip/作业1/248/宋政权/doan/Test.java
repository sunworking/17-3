package com.bdqn.doan;

public class Test {
	public static void main(String[] args) {
	       Jdbc_2 j2=new Jdbc_2();
	       Jdbc_3 j3=new Jdbc_3();
	       j2.setEname("����");
	       j2.setAddres("addres");
	       j2.setBir("1998.6.7");
	       j2.setPhone(123456);
	       j2.setMoney("money");
	       j2.setEno(2);
	       j3.add(j2);
		}

}
