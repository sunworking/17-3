package com.bdqn.yd3.jzl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.bean.Emp;

public class Xinxi{
	Emp e=new Emp();
	Jdbc j=new Jdbc();
	Connection con=j.lj();
	public int add(Emp e){
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			//ps.setInt(1, e.getEno());
			ps.setString(1, e.getEname());
			ps.setString(2, e.getEsex());
			ps.setString(3, e.getBir());
			ps.setInt(4, e.getPhone());
			ps.setInt(5, e.getMoney());
			ps.setString(6, e.getAddress());
			i=ps.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return i;
	}
	public int del(Emp e){
		String sql="delete from emp where ename=?";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,e.getEname());
			i=ps.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return i;
	}
	public int update(Emp e){
		String sql="update emp set ename=? where eno=?";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, e.getEname());
			ps.setInt(2, e.getEno());
			i=ps.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return i;
	}
}

