package com.baqn.util;

public class C {
	public static void main(String[] args) {
       A a=new A();
       B b=new B();
       a.setEname("����");
       a.setEsex("Ů");
       a.setBir("1998.6.7");
       a.setPhpne(123456);
       a.setMoney(1);
       a.setAddvess("�й���«��");
       b.add(a);
	}

}
