package com.baqn.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class B {
	Todb t=new Todb();
	Connection con=t.a();
	
	public int add(A a){
		int i=0;
		String sql="insert into emp values(sid,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(2, a.getEname());
			ps.setString(3, a.getEsex());
			ps.setString(4, a.getBir());
			ps.setInt(5, a.getPhpne());
			ps.setInt(6, a.getMoney());
			ps.setString(7, a.getAddvess());
			i=ps.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

}
