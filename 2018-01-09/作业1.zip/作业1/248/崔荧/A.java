package com.baqn.util;

public class A {
	private int eno;
	private String ename;
	private String esex;
	private String bir;
	private int phpne;
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEsex() {
		return esex;
	}
	public void setEsex(String esex) {
		this.esex = esex;
	}
	public String getBir() {
		return bir;
	}
	public void setBir(String bir) {
		this.bir = bir;
	}
	public int getPhpne() {
		return phpne;
	}
	public void setPhpne(int phpne) {
		this.phpne = phpne;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getAddvess() {
		return addvess;
	}
	public void setAddvess(String addvess) {
		this.addvess = addvess;
	}
	private int money;
	private String addvess;

}
