package com.bdqn.bean;

import com.bdqn.dao.Empdao;
/**\
 * 
 * �
 *2018��1��9������1:40:45
 */
public class Test {
	public static void main(String[] args) {
		Empdao ed=new Empdao();
		Emp e=new Emp();
		e.setEno(1);
		e.setEname("����");
		e.setEsex("Ů");
		e.setBr("1999-03-23");
		e.setPhone(123456);
		e.setMoney(2500);
		e.setAddress("f��2500");
		ed.add(e);
		ed=new Empdao();
		e=new Emp();
		e.setEno(1);
		e.setEname("����");
		e.setEsex("Ů");
		e.setBr("1999-03-23");
		e.setPhone(123456);
		e.setMoney(4500);
		e.setAddress("f��2500");
		ed.update(e);
		ed=new Empdao();
		e=new Emp();
		e.setEno(1);
		ed.delect(e);
	}

}
