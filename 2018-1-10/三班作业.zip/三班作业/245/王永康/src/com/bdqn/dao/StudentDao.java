package com.bdqn.dao;

import java.util.List;

import com.bdqn.ben.Student;

public interface StudentDao {
/**
 * ����
 * @param s
 * @return
 */

	public int zeng(Student s);
/**
 * ɾ��
 * @param sid
 * @return
 */
	public int shan(int sid);
/**
 * �޸�
 * @param s
 * @return
 */
	public int gai(Student s);
/**
 * ��ѯ
 * @param s
 * @return
 */
	public int cha(Student s);
	 
	public List<Student> query();

}
