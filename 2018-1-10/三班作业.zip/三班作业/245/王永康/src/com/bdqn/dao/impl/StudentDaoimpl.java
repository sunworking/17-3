package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.bdqn.ben.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.todb.Todb;
import com.mysql.jdbc.Statement;

/**
 * 
 * @author ������
 *
 * 2018��1��10������8:38:25
 */
public class StudentDaoimpl implements StudentDao{
	Todb t=new Todb();
	Connection con=t.todb();
	@Override
	public int zeng(Student s) {
		//��
		int i=0;
		String sql="insert into emp values(sid,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAsge());
			ps.setString(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int shan(int sid) {
		//ɾ
		int i=0;
		String sql="delete from student where sid="+(sid);
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}


	

	@Override
	public int gai(Student s) {
		// ��
		int i=0;
		String sql="update student set sname=?,ssex=?,asge=?,gid=? where sid=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int cha(Student s) {
		// ��
		public List<Student> query(){
			
		}
		return 0;
	}

}
