package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.bean.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.util.Todb;

public class StudentDaoImpl implements StudentDao {
	//��ȡ���ݿ������
  Todb t=new Todb();
  Connection con=t.todb();
  
  
	@Override
	public int addstudent(Student s) {
		String sql="insert into student values(sid,?,?,?,?)";
		int i=0;
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAsge());
			ps.setString(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int delstudent(int sid) {
		int i=0;
		String sql="delete from student where sid="+sid;
		return i;
	}

	@Override
	public int updateStudent(Student s) {
		int i=0;
		String sql="update set sname=?,ssex=?,sage=?,gid=? where sid=?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAsge());
			ps.setString(4, s.getGid());
			ps.setInt(5, s.getSid());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return i;
	}

	@Override
	public List<Student> sele() {
		String sql="select* from student";
		List<Student> list=new ArrayList<Student>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Student stu=new Student();
				stu.setSid(rs.getInt("sid"));
				stu.setSname(rs.getString("sname"));
				stu.setSsex(rs.getString("ssex"));
				stu.setAsge(rs.getInt("sage"));
				stu.setGid(rs.getString("gid"));
				list.add(stu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return list;
	}

	}
