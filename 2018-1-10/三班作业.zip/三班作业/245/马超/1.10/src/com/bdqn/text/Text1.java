package com.bdqn.text;

import com.bdqn.bean.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;

public class Text1 {
	public static void main(String[] args) {
		StudentDao s=new StudentDaoImpl();
		Student stu=new Student();
		s.delstudent(2);

	}
}
