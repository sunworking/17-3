package com.bdqn.text;

import java.util.List;

import com.bdqn.bean.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;

public class Test {
	public static void main(String[] args) {
    StudentDao sd=new StudentDaoImpl(); 
	Student	s=new Student();
	s.setSname("����");
	s.setSsex("��");
	s.setAsge(19);
	s.setGid("����");
	 int i=sd.addstudent(s);
	 if(i==1){
		 System.out.println("�����ɹ�");
	 }else{
		 System.err.println("ʧ��");
	 }
			
		}
	}
