package com.bdqn.text;

import com.bdqn.bean.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;

public class Test2 {
	public static void main(String[] args) {
		StudentDao s=new StudentDaoImpl();
		Student stu=new Student();
		stu.setSname("����");
		stu.setSsex("��");
		stu.setAsge(19);
		stu.setGid("����");
		stu.setSid(1);
		s.updateStudent(stu);
	}
}
