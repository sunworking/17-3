package com.bdqn.dao;

import java.util.List;

import com.bdqn.bean.Student;

public interface StudentDao {
	/**
	 * ����
	 * @param s
	 * @return
	 */
public int addstudent(Student s);
/**
 * ɾ��
 * @param sid
 * @return
 */
public int delstudent(int sid);
/**
 * ��
 * @param s
 * @return
 */
public int updateStudent(Student s);
/**
 * ��
 * @param s
 * @return
 */

public List<Student> sele();


