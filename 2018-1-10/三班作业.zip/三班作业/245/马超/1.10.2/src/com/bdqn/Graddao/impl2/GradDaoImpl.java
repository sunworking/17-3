package com.bdqn.Graddao.impl2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.bean.Student;
import com.bdqn.dao.GradeDao;
import com.bdqn.util.Todb;

public class GradDaoImpl implements GradeDao {
	Todb t=new Todb();
	  Connection con=t.todb();
	@Override
	public int addstudent(GradeDao s) {
		String sql="insert into student values(sid,?,?,?,?)";
		int i=0;
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getdid());
			ps.setString(2, s.getgname());
			ps.setInt(3, s.getteacher());
			
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int delstudent(int sid) {
		int i=0;
		String sql="delete from student where sid="+sid;
		return i;
	}

	@Override
	public int updateStudent(GradeDao s) {
		int i=0;
		String sql="update set sname=?,ssex=?,sage=?,gid=? where sid=?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, s.getdid());
			ps.setString(2, s.getgname());
			ps.setInt(3, s.getteacher());
			
			ps.setInt(4, s.getdid());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return i;
	}

	@Override
	public List<GradeDao> sele() {
		String sql="select* from student";
		List<Grad> list=new ArrayList<Grad>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Grad stu=new Grad();
				stu.setSid(rs.getInt("sid"));
				stu.setSname(rs.getString("sname"));
				stu.setSsex(rs.getString("ssex"));
				stu.setAsge(rs.getInt("sage"));
				stu.setGid(rs.getString("gid"));
				list.add(stu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		return list;
	}
		return null;
	}

}
