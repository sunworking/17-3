package com.bdqn.dao;

import java.util.List;



public interface GradeDao {
	
		/**
		 * ����
		 * @param s
		 * @return
		 */
	public int addstudent(GradeDao s);
	/**
	 * ɾ��
	 * @param sid
	 * @return
	 */
	public int delstudent(int sid);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int updateStudent(GradeDao s);
	/**
	 * ��
	 * @param s
	 * @return
	 */

	public List<GradeDao> sele();


}
