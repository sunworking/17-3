package com.bdqn.dao;

import com.bdqn.vo.Stu;

public interface StuDao {
	public int add(Stu s);
	public int del(int sid);
	public int update(Stu s);
	public int sel(Stu s);

}
