package com.bdqn.dao.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.bdqn.dao.StuDao;
import com.bdqn.util.Jdbc;
import com.bdqn.vo.Stu;
public class StuDaoImpl implements StuDao{
	Jdbc j=new Jdbc();
	Connection con=j.jdbc();
	@Override
	public int add(Stu s) {
		int i=1;
		String sql="insert into stu values(sid,?,?,?,?)";

		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setString(4, s.getGid());
			i=ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int del(int sid) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int update(Stu s) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public int sel(Stu s) {
		// TODO Auto-generated method stub
		return 0;
	}}
