package com.bdqn.test;

import com.bdqn.dao.impl.StuDaoImpl;
import com.bdqn.vo.Stu;

public class Test {
	public static void main(String[] args) {
		Stu s=new Stu();
		StuDaoImpl sd=new StuDaoImpl();
		s.setSname("ţ");
		s.setSid(12);
		s.setSsex("Ů");
		s.setSsex("10");
		s.setGid("11");
		
	}

}
