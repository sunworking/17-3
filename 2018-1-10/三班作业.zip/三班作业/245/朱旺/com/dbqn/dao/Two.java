package com.dbqn.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.bean.ONE;
import com.dbqn.unti.Three;

public class Two {
	Three t=new Three();
	Connection con=t.todb();
	public int add(ONE em){
		int i=0;
		String sql="insert into emp values(eno,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,em.getAddress());
			ps.setString(2, em.getEsex());
			ps.setString(3, em.getBr());
			ps.setInt(4, em.getPhone());
			ps.setDouble(5, em.getMoney());
			ps.setString(6,em.getAddress() );
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return i;
	}
	public int update(ONE em){
		int i=0;
		String sql="update emp set ename=?,esex=?,bir=?,phone=?,money=?,address=? where eno=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, em.getEname());
			ps.setString(2,em.getEsex() );
			ps.setString(3,em.getBr() );
			ps.setInt(4, em.getPhone());
			ps.setDouble(5, em.getMoney());
			ps.setString(6, em.getAddress());
			ps.setInt(7, em.getEno());
			i=ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public int delect(ONE emp){
		int i=0;
		String sql="delete from emp where eno="+emp.getEno();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	} 

}
