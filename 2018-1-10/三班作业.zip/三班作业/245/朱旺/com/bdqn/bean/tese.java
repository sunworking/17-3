package com.bdqn.bean;

import com.dbqn.dao.Two;

public class tese {
	public static void main(String[] args) {
		Two ed=new Two();
		ONE e=new ONE();
		e.setEno(1);
		e.setEname("��һ");
		e.setEsex("��");
		e.setBr("1997-05-20");
		e.setPhone(13456);
		e.setMoney(2500);
		e.setAddress("A��2300");
		ed.add(e);
		ed=new Two();
		e=new ONE();
		e.setEno(1);
		e.setEname("�ڶ�");
		e.setEsex("Ů");
		e.setBr("1997-04-20");
		e.setPhone(12346);
		e.setMoney(4700);
		e.setAddress("C��2500");
		ed.update(e);
		ed=new Two();
		e=new ONE();
		e.setEno(1);
		ed.delect(e);
	}
}
