package com.bdqn.test;

import java.util.ArrayList;
import java.util.List;

import com.dbqn.dao.impl.Studentdaoimpl;
import com.dbqn.vo.Student;

public class test_query {
public static void main(String[] args) {
	List<Student> list=new ArrayList<Student>();
	Studentdaoimpl sd=new Studentdaoimpl();
	Student s=new Student();
	list=sd.questu();
	for(Student li:list){
		System.out.println(li.getSname());
	}
}
}
