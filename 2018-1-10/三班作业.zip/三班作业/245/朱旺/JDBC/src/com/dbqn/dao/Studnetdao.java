package com.dbqn.dao;

import java.util.List;

import com.dbqn.vo.Student;

public interface Studnetdao {
public int addstu(Student s);
public int upstu(Student s);
public int delstu(int sid);
public List<Student> questu();
}
