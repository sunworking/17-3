package com.bdqn.test;

import com.dbqn.dao.Studnetdao;
import com.dbqn.dao.impl.Studentdaoimpl;
import com.dbqn.vo.Student;

public class test {
	public static void main(String[] args) {
		Studentdaoimpl sd=new Studentdaoimpl();
		Student s=new Student();
		s.setSname("��");
		s.setSsex("��");
		s.setSage(18);
		s.setSgid(3);
		sd.addstu(s);
	}
}
