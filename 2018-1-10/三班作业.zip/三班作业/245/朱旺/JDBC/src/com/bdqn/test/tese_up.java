package com.bdqn.test;

import com.dbqn.dao.impl.Studentdaoimpl;
import com.dbqn.vo.Student;

public class tese_up {
public static void main(String[] args) {
	Studentdaoimpl sd=new Studentdaoimpl();
	Student s=new Student();
	s.setSname("��");
	s.setSsex("Ů");
	s.setSage(19);
	s.setSgid(2);
	s.setSid(2);
	sd.upstu(s);
}
}
