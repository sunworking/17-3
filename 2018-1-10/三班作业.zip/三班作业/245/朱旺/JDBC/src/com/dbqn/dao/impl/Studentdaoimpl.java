package com.dbqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dbqn.dao.Studnetdao;
import com.dbqn.todb.Todb;
import com.dbqn.vo.Student;

public class Studentdaoimpl implements Studnetdao {
	Todb t=new Todb();
	Connection con=t.todb();
	@Override
	public int addstu(Student s) {
		int i=0;
		String sql="insert into student values(sid,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getSgid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int upstu(Student s) {
		int i=0;
		String sql="update student set sname=?,ssex=?,sage=?,sgid=? where sid=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getSgid());
			ps.setInt(5, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int delstu(int sid) {
		int i=0;
		String sql="delete from student where sid="+sid;
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Student> questu() {
		String sql="select * from student";
		List<Student> list=new ArrayList<Student>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Student ss=new Student();
				ss.setSgid(rs.getInt("sid"));
				ss.setSname(rs.getString("sname"));
				ss.setSsex(rs.getString("ssex"));
				ss.setSage(rs.getInt("sage"));
				ss.setSgid(rs.getInt("sgid"));
				list.add(ss);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

}
