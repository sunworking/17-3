package TEST;

import java.util.List;

import Student.Student;
import StudentDao.StudentDao;
import StudentDaoimpl.StudentDaoimpl;

public class Test {
	public static void main(String[] args) {
		StudentDao sd=new StudentDaoimpl();
		Student s=new Student();
		//s.add();
		//s.del(4);
		//s.update();
		//StudentDao s=new StudentDao();
		/**List<Student> list=s.query();
		for(Student std:list){
			System.out.println(Student.getsname());
		}*/
		s.setsname("����");
		s.setSage(20);
		s.setSsex("��");
		int i=sd.addStudent(s);
		if(i==1){
			System.out.println("�ɹ�");
		}else{
			System.out.println("ʧ��");
		}
	}
}
