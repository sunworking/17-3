package StudentDao;

import java.util.List;

import Student.Student;

public interface StudentDao {
/**
 * ��
 * @param s
 * @return
 */
	public int addStudent(Student s);
	/**
	 * ɾ
	 * @param s
	 * @return
	 */
	public int delStudent(int sid);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int updateStudent(Student s);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int queryStudent(Student s);
	List<Student> query();
}
