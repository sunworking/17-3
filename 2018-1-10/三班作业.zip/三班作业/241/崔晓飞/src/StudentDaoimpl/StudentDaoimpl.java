package StudentDaoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.ExecutableElement;

import Student.Student;
import StudentDao.StudentDao;
import unit.Todb;

public class StudentDaoimpl implements StudentDao {

	Todb t=new Todb();
	Connection con=t.todb();
	@Override
	public int addStudent(Student s) {
		String sql="insert into Student values(sid,?,?,?)";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,s.getsname());
			ps.setString(2,s.getSsex());
			ps.setInt(3,s.getSage());
			ps.setInt(4,s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return i;
	}

	@Override
	public int delStudent(int sid) {
		int i=0;
		try {
			String sql="delete from Student where sid="+sid;
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return i;
	}

	@Override
	public int updateStudent(Student s) {
		String sql="update Student setsname=?,sid=?,sage=?,asex=?";
		int i=0;
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,s.getsname());
			ps.setString(2,s.getSsex());
			ps.setInt(3,s.getSage());
			ps.setInt(4,s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TODO Auto-generated method stub
		return i;
	}

	@Override
	public List <Student> query() {
		String sql="select * from Student";
		List<Student> list=new ArrayList<Student>();

		try {
			PreparedStatement  ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Student s=new Student();
				rs.getInt("sid");
				rs.getString("sname");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
