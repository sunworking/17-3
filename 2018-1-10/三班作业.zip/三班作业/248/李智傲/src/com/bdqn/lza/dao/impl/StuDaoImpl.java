package com.bdqn.lza.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.bdqn.lza.dao.StuDao;
import com.bdqn.lza.util.Lian;
import com.bdqn.lza.vo.Stu;
/**
 * 
 * @author ���ǰ�
 *
 * 2018��1��10������8:53:05
 */

public class StuDaoImpl implements StuDao{
	Lian l=new Lian();
	Connection con=l.todb();
	@Override
	public int add(Stu s) {
		int i=0;
		String sql="insert into stu values(sid,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareCall(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int del(Stu s) {
		int i=0;
		String sql="delete from stu where sid=?";
		try {
			PreparedStatement ps=con.prepareCall(sql);
			ps.setInt(1, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int update(Stu s) {
		int i=0;
		String sql="update stu set sname=?,ssex=?,sage=?,gid=? where sid=?";
		try {
			PreparedStatement ps=con.prepareCall(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			ps.setInt(5, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Stu> query() {
		String sql="select * from stu";
		List<Stu> list=new ArrayList<Stu>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Stu s=new Stu();
				s.setSid(rs.getInt("sid"));
				s.setSname(rs.getString("sname"));
				s.setSsex(rs.getString("ssex"));
				s.setSage(rs.getInt("sage"));
				s.setGid(rs.getInt("gid"));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
