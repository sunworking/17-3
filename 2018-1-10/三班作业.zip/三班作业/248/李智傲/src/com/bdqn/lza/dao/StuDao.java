package com.bdqn.lza.dao;

import java.util.List;

import com.bdqn.lza.vo.Stu;

public interface StuDao {
	Stu s=new Stu();
	public int add(Stu s);
	public int del(Stu s);
	public int update(Stu s);
	public List<Stu> query();
}
