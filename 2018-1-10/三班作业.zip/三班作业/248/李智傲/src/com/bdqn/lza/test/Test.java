package com.bdqn.lza.test;

import java.util.List;

import com.bdqn.lza.dao.StuDao;
import com.bdqn.lza.dao.impl.StuDaoImpl;
import com.bdqn.lza.vo.Stu;
/**
 * 
 * @author ���ǰ�
 *
 * 2018��1��10������8:52:52
 */
public class Test {
	public static void main(String[] args) {
		StuDao stu=new StuDaoImpl();
		Stu s=new Stu();
		s.setSname("����");
		s.setSsex("��");
		s.setSage(18);
		s.setGid(2);
		stu.add(s);
		s.setSid(4);
		stu.del(s);
		s.setSname("ya");
		s.setSsex("��");
		s.setSage(20);
		s.setGid(1);
		s.setSid(1);
		//int i=stu.update(s);
		stu.query();
		List<Stu> list=stu.query();
		for(Stu s1:list){
			System.out.println(s1.getSname());
		}
		
		
		
	}
}
