package com.bdqn.dao.ipml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao.GradeDao;
import com.bdqn.util.Jiao;
import com.bdqn.vo.Grade;
import com.bdqn.vo.Stu;

public class GradeDaoipml implements GradeDao{
	Jiao j=new Jiao();
	Connection con=j.jdb();
	@Override
	public int add(Grade s) {
		String sql="insert into stu values(sid,?,?)";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getGname());
			ps.setString(2, s.getTeacher());
			i=ps.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	@Override
	public int del(int did) {
		int i=0;
		
		String sql="delete from stu where did="+did;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}
	@Override
	public int update(Grade s) {
		int i=0;
		String sql="update stu set gname=?,teacher=?, where sid=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getGname());
			ps.setString(2, s.getTeacher());
			
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}
	@Override
	public List<Grade> queryAll() {
		String sql="select * from grade";
		List<Grade> list=new ArrayList<Grade>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				Grade g=new Grade();
				g.setDid(rs.getInt("did"));
				g.setGname(rs.getString("gname"));
				g.setTeacher(rs.getString("teacher"));
				
				list.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
}
