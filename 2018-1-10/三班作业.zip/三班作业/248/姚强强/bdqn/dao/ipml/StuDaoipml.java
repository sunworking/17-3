package com.bdqn.dao.ipml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao.StuDao;
import com.bdqn.util.Jdbc;
import com.bdqn.vo.Stu;

/**
 * 
 * @authorҦǿǿ
 *2018��1��9������8:57:26
 */
public class StuDaoipml implements StuDao{
	Jdbc j=new Jdbc();
	Connection con=j.jdb();
	@Override
	public int add(Stu s) {
		String sql="insert into stu values(sid,?,?,?,?)";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int del(int sid) {
		int i=0;
		String sql="delete from stu where sid="+sid;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}

	@Override
	public int update(Stu s) {
		int i=0;
		String sql="update stu set sname=?,ssex=?,sage=?,gid=? where sid=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			ps.setInt(5, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}

	@Override
	public List<Stu> queryAll() {
		String sql="select * from stu";
		List<Stu> list=new ArrayList<>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				Stu s=new Stu();
				s.setSid(rs.getInt("sid"));
				s.setSname(rs.getString("sname"));
				s.setSsex(rs.getString("ssex"));
				s.setSage(rs.getInt("sage"));
				s.setGid(rs.getInt("gid"));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
