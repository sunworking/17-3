package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Stu;

/**
 * 
 * @authorҦǿǿ
 *2018��1��9������8:54:20
 */
public interface StuDao {
	public int add(Stu s);
	public int del(int sid);
	public int update(Stu s);
	public List<Stu> queryAll();
}
