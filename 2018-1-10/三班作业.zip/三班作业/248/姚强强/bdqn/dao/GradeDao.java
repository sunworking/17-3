package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Grade;
import com.bdqn.vo.Stu;

public interface GradeDao {
	public int add(Grade s);
	public int del(int did);
	public int update(Grade s);
	public List<Grade> queryAll();
}
