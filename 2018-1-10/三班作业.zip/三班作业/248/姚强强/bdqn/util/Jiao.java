package com.bdqn.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Jiao {
	private String NAME="root";
	private String PWD="root";
	private String UPL="jdbc:mysql://localhost:3306/test";
	private String DRIVER="com.mysql.jdbc.Driver";
	public Connection jdb(){
		Connection con=null;
		
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(UPL, NAME, PWD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
}
