package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.StuDao;
import com.bdqn.dao.ipml.StuDaoipml;
import com.bdqn.vo.Stu;

public class Test {
	public static void main(String[] args) {
		StuDao sd=new StuDaoipml();
		Stu s=new Stu();
		/*��
		  s.setSname("��ë");
		  s.setSsex("Ů");
		  s.setSage(19);
		  s.setGid(3);
		  sd.add(s);
		*/
		/*ɾ
		 * sd.del(2);
		 */
		/*	��
		  s.setSname("С��ݮ");		   
		  s.setSsex("Ů");
		  s.setGid(2);
		  s.setSage(20);
		  s.setSid(1);
		 sd.update(s);*/
		/*
		 * ��
		 */
		List<Stu> list=sd.queryAll();
		for(Stu stu:list){
			System.out.println(stu.getSname());
		}
		
	}
}
