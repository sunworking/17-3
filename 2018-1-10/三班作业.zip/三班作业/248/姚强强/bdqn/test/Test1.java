package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.GradeDao;
import com.bdqn.dao.StuDao;
import com.bdqn.dao.ipml.GradeDaoipml;
import com.bdqn.dao.ipml.StuDaoipml;
import com.bdqn.vo.Grade;
import com.bdqn.vo.Stu;

public class Test1 {
	public static void main(String[] args) {
		GradeDao gd=new GradeDaoipml();
		Grade g=new Grade();
		/*��
	  g.setgname("��ѧ");
	  g.seteacher("����");

	  g.setdid(1);
	  gd.add(g);
		 */
		/*ɾ
		 * gd.del(2);
		 */
		/*	��
	  g.setSname("����");		   
	  g,setTeacher("����");
	  g.setDid(1);
	 sd.update(s);*/
		/*
		 * ��
		 */
		List<Grade> list=gd.queryAll();
		for(Grade grade:list){
			System.out.println(grade.getGname());
		}

	}
}

