package com.bdqn.daoiml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bdqn.dao.Studentdao;
import com.bdqn.util.Todb;
import com.bdqn.vo.Student;


public class Studentdaoiml implements Studentdao{
	Todb t=new Todb();
	Connection con=t.todb();
	Student stu=new Student();
	
	//��
	public int add(Student s) {
		int i=1;
		String sql="insert into student values(sid,?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			ps.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return i;
	}

	//ɾ
	public int delete(int id) {
		int i=1;
		String sql="delete from student where sid="+id;
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return i;
	}

	//��
	public int update(Student s) {
		int i=1;
		String sql="update student set where sid=? sname=? ssex=? sage=? gid=?";
		
		
		
		return i;
	}

}
