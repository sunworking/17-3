package com.bdqn.test;

import com.bdqn.dao.Studentdao;
import com.bdqn.daoiml.Studentdaoiml;
import com.bdqn.vo.Student;

public class test {
	public static void main(String[] args) {


		Studentdao std=new Studentdaoiml();
		Student stud=new Student();
		stud.setGid(2);
		stud.setSage(18);
		stud.setSname("sname");
		stud.setSsex("ssex");
		std.add(stud);


	}
}