package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.Studentdao;
import com.bdqn.daoiml.Studentdaoiml;
import com.bdqn.vo.Student;

public class test {
	public static void main(String[] args) {


		Studentdao std=new Studentdaoiml();
		Student stud=new Student();
		stud.setGid(2);
		stud.setSage(18);
		stud.setSname("����");
		stud.setSsex("Ů");
		stud.setSid(1);
		int i=std.add(stud);
		if (i==1) {
			System.out.println("y");
			
		}else {
			System.out.println("n");
		}


	}
	Student s=new Student(); 
	List<Student> list=s.query("");
	for(Student student:list){
		System.out.println(s.getSname());
	}
	}
}
	
	
	
