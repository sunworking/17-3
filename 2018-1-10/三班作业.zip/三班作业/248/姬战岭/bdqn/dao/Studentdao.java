package com.bdqn.dao;

import com.bdqn.vo.Student;

public interface Studentdao {
	
		public int add(Student s);
		
		public int delete(int id);
		 
		public int update(Student s);
		
		public int select(Student s);
	

}
