package com.bdqn.daoiml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao.Studentdao;
import com.bdqn.util.Todb;
import com.bdqn.vo.Student;

public class Studentdaoiml implements Studentdao{

	Todb t=new Todb();
	Connection con=t.todb();
	Student stu=new Student();

	//��
	public int add(Student s) {
		int i=1;
		String sql="insert into student values(sid,?,?,?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			ps.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return i;
	}

	//ɾ
	public int delete(int id) {
		int i=1;
		String sql="delete from student where sid="+id;
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return i;
	}

	//��
	public int update(Student s) {
		int i=1;
		String sql="update student set sname=?,ssex=?,sage=?,gid=? where sid=1";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setInt(2, s.getSage());
			ps.setString(3, s.getSsex());
			ps.setInt(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return i;
	}

	//��
	public int select(Student s) {
		public List<Student>query(){
			String sql="select * from Student";
			List<Student> list=new ArrayList<Student>();
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				Student std=new Student();
				std.setSid(rs.getInt("sid"));
				std.setSage(18);
				std.setSname("sname");
				std.setSsex("ssex");
				std.setGid(1);
				list.add(std);
			}

		}

		return list;

	}

}
