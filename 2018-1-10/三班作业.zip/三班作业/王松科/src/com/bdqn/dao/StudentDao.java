package com.bdqn.dao;

import java.util.List;

import com.bdqn.bean.Student;

/**
 * ��  ɾ  �� ��
 * @author ���ɿ�
 *2018-1-10����9:01:07
 *
 */
public interface StudentDao {
	public  int   addStudent(Student s);
	public  int   delStudent(Student s);
	public  int   updateStudent(Student s);
	public  List<Student> queryallStudent();


}
