package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.bdqn.bean.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.util.Todb;


/**
 * ʵ�ֽӿ�
 * @author ���ɿ�
 *2018-1-10����9:01:14
 *
 */
public class StudentDaoImpl  implements StudentDao{
	/**
	 * ��������
	 */
	Todb t=new Todb();
	Connection con=t.todb();
	/**
	 * ����ѧ�������
	 */
	public int addStudent(Student s ) {
		int i=0;
		String  sql="insert into student values(sid,?,?,?,?)";
		try {
			PreparedStatement  ps=con.prepareStatement(sql);
			ps.setString(1,s.getSname() );
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAsge());
			ps.setInt(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	/**
	 * ����ѧ�����ɾ��
	 */
	public int delStudent(Student s) {
		int   i=0;
		String  sql="delete  from  student where sid=?  ";
		try {
			PreparedStatement   ps=con.prepareStatement(sql);
			ps.setInt(1, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	/**
	 * ����ѧ����ĸ�
	 */
	public int updateStudent(Student s) {
		int i=0;
		String  sql="update student set sname=?,ssex=?,asge=?,gid=? where sid=? ";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAsge());
			ps.setInt(4, s.getGid());
			ps.setInt(5, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	/**
	 * ����ѧ����Ĳ�
	 */
	public List<Student> queryallStudent() {
		String  sql="select  *   from student ";
		List<Student>  list=new ArrayList<Student>();
		try {
			PreparedStatement   ps= con.prepareStatement(sql);
			ResultSet   rs= ps.executeQuery();
			while(rs.next()){
				Student  s=new  Student();
				s.setSid(rs.getInt("sid"));
				s.setSname(rs.getString("sname"));
				s.setSsex(rs.getString("ssex"));
				s.setAsge(rs.getInt("asge"));
				s.setGid(rs.getInt("gid"));
				list.add(s);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}



}
