package com.bdqn.yd3.wsk;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
/**
 * 
 * @author ���ɿ�
 *
 * 2017��12��24������11:26:39
 */
public class Test {


	public static void main(String[] args) {

		try {
			SAXReader sr=new SAXReader();
			Document d=sr.read(new File("src/Qwq.xml"));
			Element element=d.getRootElement();
			Iterator it=element.elementIterator();
			while(it.hasNext()){
				Element e=(Element)it.next();
				List<Attribute> list=e.attributes();
				for (Attribute a : list) {
					System.out.println(a.getName()+a.getValue());
				}
				Iterator itt=e.elementIterator();
				while(itt.hasNext()){
					Element ee=(Element)itt.next();
					System.out.println(ee.getName()+ee.getText());
					
				}
				
			}
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}