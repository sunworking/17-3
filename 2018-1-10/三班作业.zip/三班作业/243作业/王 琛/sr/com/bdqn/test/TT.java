package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

public class TT {
public static void main(String[] args) {
	StudentDao s=new StudentDaoImpl();
	Student s1=new Student();
	/*s1.setSname("����");
	s1.setSsex("��");
	s1.setSage(17);
	s1.setGid(3);*/
	/*if(i==1){
		System.out.println("�ɹ�");
	}else{
		System.out.println("ʧ��");
	}*/
	List<Student> list=s.query();
	for(Student st:list){
		System.out.println(st.getSname());
	}
}
}
