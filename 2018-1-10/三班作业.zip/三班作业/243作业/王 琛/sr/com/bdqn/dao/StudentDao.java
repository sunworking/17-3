package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Student;

public interface StudentDao {
public int add(Student s);
public int del(int sid);
public int update(Student s);
public List<Student> query();
}
