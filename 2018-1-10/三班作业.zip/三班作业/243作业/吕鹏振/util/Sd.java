package com.bdqn.yd3.util;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

/**
 * 
 * @author ������
 *
 * 2018-1-10����8:27:35
 */
public class Sd {
	private final String NAME="root";
	private final String MM="root";
	private final String URL="jdbc:mysql://localhost:3306/test";
	private final String DRIVER="com.mysql.jdbc.Driver";
	public Connection vv(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=(Connection) DriverManager.getConnection(URL, NAME, MM);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
}
