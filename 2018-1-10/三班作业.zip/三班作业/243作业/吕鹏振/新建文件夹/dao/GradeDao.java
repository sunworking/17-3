package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Grade;
public interface GradeDao {
public int add(Grade s);
public int del(int did);
public int update(Grade s);
public List<Grade> query();

}
