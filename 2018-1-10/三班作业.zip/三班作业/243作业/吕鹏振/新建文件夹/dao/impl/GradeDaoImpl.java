package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao.GradeDao;
import com.bdqn.uitl.T;
import com.bdqn.vo.Grade;

public class GradeDaoImpl implements GradeDao {
	T t=new T();
	Connection con=t.s();
	@Override
	public int add(Grade s) {
		int i=0;
		String sql="insert into grade values(did,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getGname());
			ps.setString(2, s.getTeacher());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}

	@Override
	public int del(int did) {
		int i=0;
		String sql="delete from grade where did="+did;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int update(Grade s) {
		int i=0;
		String sql="update grade set gname=?,teacher=? where did=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getGname());
			ps.setString(2, s.getTeacher());
			ps.setInt(3, s.getDid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return i;
	}

	@Override
	public List<Grade> query() {
		String sql="select * from grade";
		List<Grade> list=new ArrayList<Grade>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet r=ps.executeQuery();
			while(r.next()){
				Grade s=new Grade();
				s.setDid(r.getInt("did"));
				s.setGname(r.getString("gname"));
				s.setTeacher(r.getString("teacher"));
				list.add(s);			
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

}
