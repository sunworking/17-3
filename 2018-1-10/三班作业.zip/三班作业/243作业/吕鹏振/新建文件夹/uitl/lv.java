package com.bdqn.uitl;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Lv{
	private final String YH="root";
	private final String MIMA="root";
	private final String SIP="jdbc:mysql://localhost:3306/em";
	private final String QD="com.mysql.jdbc.Driver";
	public Connection s(){
		Connection con=null;
		try {
			Class.forName(QD);
			con=DriverManager.getConnection(SIP, YH, MIMA);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	public static void main(String[] args) {
		Lv l=new Lv();
		System.out.println(t.s());
	}
	}


