package com.bdqn.test;
import java.util.List;

import com.bdqn.dao.GradeDao;
import com.bdqn.dao.impl.GradeDaoImpl;
import com.bdqn.vo.Grade;


public class Test {
public static void main(String[] args) {
	GradeDao s=new GradeDaoImpl();
	Grade t=new Grade();
	/*t.setGname("����");
	t.setTeacher("��");
	int i=s.add(t);
	if(i==1){
		System.out.println("�ɹ�");
	}else{
		System.out.println("ʧ��");
	}*/
	List<Grade> list=s.query();
	for(Grade g:list){
		System.out.println(g.getDid());
	}
	
}
}
