package com.bdqn.yd3.Dao;

import com.bdqn.yd3.vo.Student;

/**
 * 
 * @author ������
 *
 * 2018-1-10����8:54:30
 */
public interface StudentDao {
	public int zeng(Student wo);
	/**
	 * ��
	 */
	public int shan(Student de);
	/**
	 * ɾ
	 */
	public int gai(Student fang);
	/**
	 * ��
	 */
	public int cha(Student fa);
	/**
	 * ��
	 */
}
