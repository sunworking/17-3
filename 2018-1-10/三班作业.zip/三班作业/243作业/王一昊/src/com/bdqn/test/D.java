package com.bdqn.test;

import java.util.List;

import com.bdqn.vo.T;

public interface D {
	public int add(T s);
	public int del(int did);
	public int update(T s);
	public List<T> qq();
	}
