package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.bdqn.test.D;
import com.bdqn.util.I;
import com.bdqn.vo.T;


public class R implements D{
	I i=new I();
	Connection con=i.s();
	@Override
	public int add(T s) {
		int i=0;
		String sql="insert into grade values(eno,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getEname());
			ps.setString(1, s.getEsex());
			ps.setString(1, s.getBir());
			ps.setString(1, s.getPhone());
			ps.setString(1, s.getMoney());
			ps.setString(1, s.getAddress());
			i=ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int del(int did) {
		int i=0;
		String sql="delete from grade where did="+did;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			i=ps.executeUpdate();
			return i;
	}
	};
	@Override
	public int update(T s) {
		int i=0;
		
		String sql="update grade set ename=?,eses=?,bir=?,phone=?,money=?,address=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getEname());
			ps.setString(1, s.getEsex());
			ps.setString(1, s.getBir());
			ps.setString(1, s.getPhone());
			ps.setString(1, s.getMoney());
			ps.setString(1, s.getAddress());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;


	}

	@Override
	public List<T> qq() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
