package com.bdqn.util;

public class E {
	public static void main(String[] args) {
		I i=new I();
	
		System.out.println(	i.s());
	}
}
