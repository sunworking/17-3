package com.bdqn.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class I {
	String NAME="root";
	String MIMA="root";
	String DIP="jdbc:mysql://localhost:3306/e";
	String DR="com.mysql.jdbc.Driver";
	public Connection s(){
		try {
			Connection con=null;
			Class.forName(DR);
			con=DriverManager.getConnection(DIP, NAME, MIMA);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
}
