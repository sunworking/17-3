package com.bdqn.test;

import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.dao1.StudentDao;
import com.bdqn.vo.Student;

public class Test2 {
	public static void main(String[] args) {
		GradeDao gd=new GradeDaoImpl();
		Grade g=new Grade();
		sd.del(1);

}
}