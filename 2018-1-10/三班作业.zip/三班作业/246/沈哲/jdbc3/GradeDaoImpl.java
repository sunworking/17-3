package com.bdqn.Grade.Dao.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.Grade.Dao.GradeDao;
import com.bdqn.bean.Grade;
import com.bdqn.util.DB;

public class GradeDaoImpl implements GradeDao{
		DB d=new DB();
		Connection con=d.db();
		@Override
		public int add(Grade g) {
			int i=0;
			try {
				String sql="insert into student values(did,?,?)";
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString(1,g.getGname());
				ps.setString(2, g.getTeacher());
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
		}

		@Override
		public int del(int did) {
			int i=0;
			try {
				String sql="delete from Grade where did="+did;
				PreparedStatement ps=con.prepareStatement(sql);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
		}

		@Override
		public int update(Grade g) {
			int i=0;
			try {
				String sql="update Grade set Gname=?,Teacher=? where did=?";
				PreparedStatement	ps=con.prepareStatement(sql);
				ps.setString(1, g.getGname());
				ps.setString(2, g.getTeacher());
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return i;
		}

		@Override
		public List<Grade> query() {
			String sql="select * from grade";
			List<Grade> list=new ArrayList<Grade>();
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					Grade g=new Grade();
					g.setDid(rs.getInt("did"));
					g.setGname(rs.getString("gname"));
					g.setTeacher(rs.getString("teacher"));
					list.add(g);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		} 
			
		}	