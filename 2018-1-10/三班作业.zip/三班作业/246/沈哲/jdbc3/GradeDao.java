package com.bdqn.Grade.Dao;

import java.util.List;

import com.bdqn.bean.Grade;

public interface GradeDao {
	public int add(Grade g);
	
	
	public int del(int did);
	
	
	public int update(Grade g);
	
	
	public List<Grade> query();

}
