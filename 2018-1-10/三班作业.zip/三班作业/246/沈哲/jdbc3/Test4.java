package com.bdqn.test;

import java.util.ArrayList;
import java.util.List;

import com.bdqn.Grade.Dao.GradeDao;
import com.bdqn.Grade.Dao.Impl.GradeDaoImpl;
import com.bdqn.bean.Grade;

public class Test4 {
	public static void main(String[] args) {
		GradeDao gd=new GradeDaoImpl();
		List<Grade> list=gd.query();
		for (Grade grade : list) {
			System.out.println(grade.getDid()+"\t"+grade.getGname()+"\t"+grade.getTeacher());
			
			
		}
		
		
		
	}

}
