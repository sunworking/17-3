package com.bdqn.yd3.shenzhe;

import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.dao1.StudentDao;
import com.bdqn.vo.Student;

public class Test1 {
	public static void main(String[] args) {
		GradeDao gd=new GradeDaoImpl();
		Grade g=new Grade();
		g.setDid("1");
		g.setGname("2��");
		g.setTeacher("����");
		sd.update(s);
	}

}

	

}
