package com.bdqn.yd3.shenzhe;

import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.dao1.StudentDao;
import com.bdqn.vo.Student;

public class Test1 {
	public static void main(String[] args) {
		StudentDao sd=new StudentDaoImpl();
		Student s=new Student();
		s.setSid(2);
		s.setSname("����");
		s.setSsex("��");
		s.setSage(19);
		s.setGid(2);
		sd.update(s);
	}

}

	

}
