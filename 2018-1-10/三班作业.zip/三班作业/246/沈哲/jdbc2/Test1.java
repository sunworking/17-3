package com.bdqn.test;

import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.dao1.StudentDao;
import com.bdqn.vo.Student;
/**
 * 
 * @author ����
 *��
 * 2018��1��10������9:27:38
 */
public class Test1 {
	public static void main(String[] args) {
		StudentDao sd=new StudentDao();
		Student s=new Student();
		s.setSname("����");
		s.setEsex("��");
		s.setSage("19");
		s.setGid(2);
		sd.add(e);
		
	
		
		
	}
	
	

}
