package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.StudentDao;
import com.bdqn.daoimpl.StudentDaoImpl;
import com.bdqn.vo.Student;

public class Tset {
	public static void main(String[] args) {
		StudentDao s=new StudentDaoImpl();
	List<Student> list=s.query();
	for (Student stu : list) {
		System.out.println(stu.getSid()+"\t"+stu.getSname()+"\t"+stu.getSsex()+"\t"+stu.getSage()+"\t"+stu.getGid());
		
	}
	
	
	
	
}

}
