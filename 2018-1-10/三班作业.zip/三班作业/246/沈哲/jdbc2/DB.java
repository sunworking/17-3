package com.bdqn.util;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;


public class DB {
	private final String NAME="root";//�û���
	private final String PWD="root";//����
	private final String URL="jdbc:mysql://localhost:3306/stu";
	private	final String DRIVER="com.mysql.jdbc.Driver";
	
	public Connection db() {//��������
		Connection con=null;
	try {
		Class.forName(DRIVER);
		con=DriverManager.getConnection(URL, NAME, PWD);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con;
	}
	public static void main(String[] args) {
		
		DB b=new DB();
		Connection con=b.db();
		System.out.println(con);
	}
}
