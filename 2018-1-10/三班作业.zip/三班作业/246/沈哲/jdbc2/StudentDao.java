package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Student;

public interface StudentDao {
	/**
	 * ��
	 * @return
	 */
	public int add(Student s);
	
	/**
	 * ɾ
	 * @return
	 */
	
	public int	del(int sid);
	
	/**
	 * ��
	 * @return
	 */
	
	
	public int update(Student s);
	
	/**
	 * ��
	 * @return
	 */
	public List<Student> query();
	
	
	


}
