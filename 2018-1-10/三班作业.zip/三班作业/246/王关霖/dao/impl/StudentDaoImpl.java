package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao1.StudentDao;
import com.bdqn.util.Jdbc;
import com.bdqn.vo.Student;

public class StudentDaoImpl implements StudentDao {
	Jdbc j=new Jdbc();
	Connection con=j.jdbc();
	@Override
	public int add(Student s) {
		int i=0;
		String sql="insert  into    student   values(sid,?,?,?,?)";
		try {
			PreparedStatement  ps=	con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int del(int sid) {
		int i=0;
		String sql="delete  from  student   where sid="+sid;

		try {
			PreparedStatement	ps = con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public int update(Student s) {
		int i=0;
		String sql="update  student set sname=?,ssex=?,sage=?,gid=?  where  sid=?";
		try {
			PreparedStatement	ps = con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getSage());
			ps.setInt(4, s.getGid());
			ps.setInt(5, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Student> select() {
		List<Student> list =new ArrayList<Student>();
		String sql="select  *   from   student    ";
		try {
			PreparedStatement	ps = con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				Student  s=new Student();
				s.setSid(rs.getInt("sid"));
				s.setSname(rs.getString("sname"));
				s.setSsex(rs.getString("ssex"));
				s.setSage(rs.getInt("sage"));
				s.setGid(rs.getInt("gid"));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

}
