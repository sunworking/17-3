package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao1.GradeDao;
import com.bdqn.util.Jdbc;
import com.bdqn.vo.Grade;


public class GradeDaoImpl implements GradeDao {
	Jdbc j=new Jdbc();
	Connection con=j.jdbc();
	Grade g=new Grade();
	@Override
	public int add(Grade g) {
int i=0;
String sql="insert  into    grade   values(did,?,?)";
try {
	PreparedStatement ps=  con.prepareStatement(sql);
	ps.setString(1,g.getGname() );
	
	ps.setString(2,g.getTeacher() );
	i=ps.executeUpdate();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		return i;
	}

	@Override
	public int del(Grade did) {
		int i=0;
		String sql="delete  from  grade   where did=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, g.getDid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return i;
	}

	@Override
	public int update(Grade g) {
		int i=0;
		String sql="update  grade set gname=?,teacher=?where did=?";
		try {
			PreparedStatement	ps = con.prepareStatement(sql);
			ps.setString(1, g.getGname());
			ps.setString(2, g.getTeacher());
			ps.setInt(3, g.getDid());
			i=ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Grade> update() {
		List<Grade > list =new ArrayList<Grade >();
		String sql="select  *   from   grade   ";
		
			ResultSet rs;
			
				PreparedStatement ps;
				try {
					ps = con.prepareStatement(sql);
					rs = ps.executeQuery();
					while (rs.next()) {
						Grade  s=new Grade();
						s.setDid(rs.getInt("did"));
						s.setGname(rs.getString("gname"));
						s.setTeacher(rs.getString("teacher"));
						list.add(s);
						}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	
			return list;

}
}