package com.bdqn.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Jdbc {
	private final String NAME="root";
	private final String PWD="root";
	private final String URL="jdbc:mysql://localhost:3306/test";
	private final String DRIVER="com.mysql.jdbc.Driver";
	public Connection jdbc(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(URL, NAME, PWD);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	return con;
	
}
	public static void main(String[] args) {
		Jdbc j=new Jdbc();
		Connection con=j.jdbc();
		System.out.println(con);
	}
}
