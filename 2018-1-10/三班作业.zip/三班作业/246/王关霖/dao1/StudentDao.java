package com.bdqn.dao1;

import java.util.List;

import com.bdqn.vo.Student;

public interface StudentDao {
	/**
	 * ����
	 * @param s
	 * @return
	 */
	public int add(Student s);
	/**
	 * ɾ
	 * @param i
	 * @return
	 */
	public int del(int sid);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int update (Student s);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public List<Student> select();


}
