package com.bdqn.dao1;

import java.util.List;

import com.bdqn.vo.Grade;

public interface GradeDao {
	/**
	 * ��
	 * @param g
	 * @return
	 */
public int  add(Grade g);
/**
 * ɾ
 * @param did
 * @return
 */
public int   del(Grade did );

/**
 * ��
 * @param g
 * @return
 */
public int  update (Grade g);
/**
 * ��
 * @param g
 * @return
 */
public List<Grade>  update ();


}
