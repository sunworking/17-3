package com.bdqn.test;

import java.util.List;
import java.util.Scanner;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.dao1.StudentDao;
import com.bdqn.vo.Student;

public class test {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	StudentDao stu=new StudentDaoImpl();
	Student s=new Student();
	         s.setSname("asdad");
	         s.setSsex("asdaweds");
	         s.setSage(20);
	         s.setGid(2);
	         stu.add(s);
	         s.setSage(1);
	         s.setSname("sdafsa");
	         s.setSsex("nan");
	         s.setSid(1);
	         stu.update(s);
	         stu.del(1);
	
	  List<Student> list= stu.select();	
	 
			for (Student st : list) {
				System.out.println(st.getSname());
			}
			
			
	
}
}
