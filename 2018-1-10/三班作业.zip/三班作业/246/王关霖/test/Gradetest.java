package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.impl.GradeDaoImpl;
import com.bdqn.dao1.GradeDao;
import com.bdqn.vo.Grade;
import com.bdqn.vo.Student;

public class Gradetest {
public static void main(String[] args) {
	Grade g=new Grade();
	GradeDao gd=new GradeDaoImpl();
	/**g.setGname("sada");
	g.setTeacher("efwefd");
	gd.add(g);
	g.setGname("asdaws");
	g.setTeacher("sadardfasd");
	g.setDid(1);
	gd.update(g);
	g.setDid(1);
	gd.del(g);*/
	List<Grade>  list=   gd.update();
	for (Grade ad : list) {
		System.out.println(ad.getGname());
	}
	
}
}
