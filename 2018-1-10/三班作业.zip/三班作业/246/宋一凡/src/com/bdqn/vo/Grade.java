package com.bdqn.vo;
/**
 * 
 * @author ��һ��
 *
 * 2018��1��10������8:17:01
 */
public class Grade {
	private int gid;
	private String gname;
	private String teacher;
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getTeacher() {
		return teacher;
	}
	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}
}
