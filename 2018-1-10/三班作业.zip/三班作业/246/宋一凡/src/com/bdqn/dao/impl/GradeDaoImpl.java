package com.bdqn.dao.impl;

import java.security.KeyStore.ProtectionParameter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao.GradeDao;
import com.bdqn.util.Todb;
import com.bdqn.vo.Grade;
import com.bdqn.vo.Student;

/**
 * 
 * @author ��һ��
 *
 * 2018��1��10������8:29:59
 */
public class GradeDaoImpl implements GradeDao{
		Todb t=new Todb();
		Connection con=t.todb();
		@Override
		public int add(Grade g) {
			int i=0;
			String sql="insert into grade values (?,?,?)";
			try {
				PreparedStatement ps=con.prepareCall(sql);
				ps.setInt(1,g.getGid());
				ps.setString(2, g.getGname());
				ps.setString(3, g.getTeacher());
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
		}
		@Override
		public int del(int gid) {
			int i=0;
			String sql="delete from grade where gid="+gid;
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
		}
		@Override
		public int update(Grade g) {
			int i=0;
			String sql="update student set gname=?,teacher=? where gid=?";
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				
				ps.setString(1, g.getGname());
				ps.setString(2, g.getTeacher());
				ps.setInt(3, g.getGid());
				i=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return i;
		}
		@Override
		public List<Grade> query() {
			List<Grade> list=new ArrayList<Grade>();
			String sql="select * from grade";
			try {
				PreparedStatement ps=con.prepareStatement(sql);
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					Grade g=new Grade();
					g.setGid(rs.getInt("gid"));
					g.setGname(rs.getString("gname"));
					g.setTeacher(rs.getString("teacher"));
					list.add(g);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return list;
		}
		
	
}
