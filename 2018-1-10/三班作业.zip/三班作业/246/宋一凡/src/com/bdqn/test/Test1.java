package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

/**
 * 
 * @author ��һ��
 *
 * 2018��1��10������9:04:02
 */
public class Test1 {
	public static void main(String[] args) {
		StudentDao st=new StudentDaoImpl();
		Student s=new Student();
		s.setGid(2);
		s.setSage(13);
		s.setSid(123123);
		s.setSname("asd");
		s.setSsex("a");
		st.add(s);
		List<Student> list=st.query();
		for(Student sd:list){
			System.out.println(s.getSname());
		}
	}
}
