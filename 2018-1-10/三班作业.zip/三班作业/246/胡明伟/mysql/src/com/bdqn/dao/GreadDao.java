package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Gread;



public interface GreadDao {
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int add(Gread g);
	/**
	 * ɾ
	 * @param sid
	 * @return
	 */
	public int del(int gid);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int update(Gread g);
	/**
	 * ��
	 * @return
	 */
	public List<Gread> query();

}
