package com.bdqn.test;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

public class TestS3 {
		public static void main(String[] args) {
			StudentDao sd=new StudentDaoImpl();
			Student s=new Student();
			s.setSname("����");
			s.setSsex("Ů");
			s.setSage(18);
			s.setGid(3);
			s.setSid(3);
			sd.update(s);
			
			
		}

}
