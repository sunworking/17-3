package com.bdqn.test;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

public class TestS1 {
	public static void main(String[] args) {
		StudentDao sd=new StudentDaoImpl();
		Student s=new Student();
		s.setSname("����");
		s.setSsex("��");
		s.setSage(19);
		s.setGid(3);
		sd.add(s);
		
		
	}

}
