package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

public class TestS4 {
	public static void main(String[] args) {
		StudentDao sd=new StudentDaoImpl();
		List<Student> l=sd.query();
		for(Student s:l){
			System.out.println(s.getSname());
			
		}
	}

}
