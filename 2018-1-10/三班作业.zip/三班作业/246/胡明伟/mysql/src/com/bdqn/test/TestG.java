package com.bdqn.test;

import com.bdqn.dao.GreadDao;
import com.bdqn.dao.impl.GreadDaoImpl;
import com.bdqn.vo.Gread;

public class TestG {
	public static void main(String[] args) {
		Gread g=new Gread();
		GreadDao gd=new GreadDaoImpl();
		g.setDid(1);
		g.setGname("����");
		g.setTeacher("teacher");
		gd.add(g);
	}

}
