package com.bdqn.dao;

import java.util.List;

import com.bdqn.vo.Student;

public interface StudentDao {
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int add(Student s);
	/**
	 * ɾ
	 * @param sid
	 * @return
	 */
	public int del(int sid);
	/**
	 * ��
	 * @param s
	 * @return
	 */
	public int update(Student s);
	/**
	 * ��
	 * @return
	 */
	public List<Student> query();

}
