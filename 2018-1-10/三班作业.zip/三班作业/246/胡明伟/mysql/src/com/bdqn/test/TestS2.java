package com.bdqn.test;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

public class TestS2 {
	public static void main(String[] args) {
		StudentDao sd=new StudentDaoImpl();
		Student s=new Student();
		sd.del(2);
	}

}
