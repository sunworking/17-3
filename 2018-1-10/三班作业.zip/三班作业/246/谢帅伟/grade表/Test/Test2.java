package Test;

import java.util.List;

import com.baqn.bean.Ben;
import com.baqn.impl.Studentimpl;

public class Test2 {
public static void main(String[] args) {
	Studentimpl s=new Studentimpl();
	List<Ben> list=s.query();
	for (Ben ben : list) {
		System.out.println(ben.getGname());
	}
	
}
}
