package Test;

import com.baqn.bean.Ben;
import com.baqn.dao.StudentDao;
import com.baqn.impl.Studentimpl;

public class Test {
	public static void main(String[] args) {
		StudentDao st=new Studentimpl();
		Ben  b=new Ben();
		b.setGname("����һ��");
		b.setTeacher("ҶƼ");
		int i=st.addStudent(b);
		if(i==1){
			System.out.println("�����ɹ�");
		}else{
			System.out.println("����ʧ��");
		}
	}





}
