package com.baqn.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.baqn.bean.Ben;
import com.baqn.dao.StudentDao;
import com.baqn.util.Student;

public class Studentimpl implements StudentDao {
	Student std=new Student();
	Connection con=std.todb();
	@Override
	public int addStudent(Ben b) {
		int i=0;
		String sql="insert into grade values(did,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, b.getGname());
			ps.setString(2, b.getTeacher());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int delStudent(int did) {
		String sql="delete from  grade where did="+did;
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateStudent(Ben b) {
		String sql="update grade set gname=?,teacher=?,did=?";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, b.getGname());
			ps.setString(2, b.getTeacher());
			ps.setInt(3, b.getDid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
public List<Ben> query (){
String sql="select *from grade";
List<Ben> list=new ArrayList<Ben>();
try {
	PreparedStatement ps=con.prepareStatement(sql);
	ResultSet rs=ps.executeQuery();
	while(rs.next()){
		Ben s=new Ben();
		s.setDid(rs.getInt("did"));
		s.setGname(rs.getString("gname"));
		s.setTeacher(rs.getString("teacher"));
		list.add(s);
	}
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
return list;
}
}
