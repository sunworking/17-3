package com.baqn.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Student {
	private final String name="root";
	private final String pass="root";
	private final String url="jdbc:mysql://localhost:3306/test";
	String DRIVER="com.mysql.jdbc.Driver";
	Connection con=null;
	public Connection todb(){
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(url, name, pass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}	
	
}
