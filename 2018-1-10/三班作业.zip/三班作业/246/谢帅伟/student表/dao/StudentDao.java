package com.baqn.dao;

import com.baqn.bean.Ben;

public interface StudentDao {
	public int addStudent(Ben b);
	/**
	 * ����
	 * @return
	 */
	public int delStudent(int sid);
	/**
	 * ɾ��
	 * @return
	 */
	public int updateStudent(Ben b);
	/**
	 * �޸�
	 */
}
