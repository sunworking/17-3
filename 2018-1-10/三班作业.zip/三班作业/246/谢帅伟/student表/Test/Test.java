package Test;

import com.baqn.bean.Ben;
import com.baqn.dao.StudentDao;
import com.baqn.impl.Studentimpl;

public class Test {
	public static void main(String[] args) {
		StudentDao st=new Studentimpl();
		Ben  b=new Ben();
		b.setSname("����");
		b.setSsex("��");
		b.setAsge(18);
		b.setGid(1);
		b.setSid(1);
		int i=st.delStudent(1);
		if(i==1){
			System.out.println("�����ɹ�");
		}else{
			System.out.println("����ʧ��");
		}
	}





}
