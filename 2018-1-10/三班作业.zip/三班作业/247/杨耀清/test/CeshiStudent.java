package com.bdqn.test;

import java.util.ArrayList;
import java.util.List;

import com.bdqn.bean.StudentBean;
import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;

/**
 * ������
 * @author ��ҫ��
 *
 * 2018��1��10������5:02:01
 */
public class CeshiStudent {
	public static void main(String[] args) {
		StudentDao sdi=new StudentDaoImpl();
		StudentBean sttb=new StudentBean();
		/**
		 * ����
		 */
//		sttb.setSname("����");
//		sttb.setSsex("��");
//		sttb.setAsge(20);
//		sttb.setGid(3);
//		sdi.add(sttb);
		/**
		 * �޸�
		 */
//		sttb.setSid(3);
//		sttb.setSname("����");
//		sttb.setSsex("Ů");
//		sttb.setAsge(22);
//		sttb.setGid(2);
//		sdi.upd(sttb);
		/**
		 * ɾ��
		 */
//		sdi.del(3);
		/**
		 * ��ѯ
		 */
//		List<StudentBean> list=sdi.sel();
//		for(StudentBean ssbb:list){
//			System.out.println(ssbb.getSname());
//		}
	}
}
