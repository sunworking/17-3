package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.bdqn.bean.StudentBean;
import com.bdqn.dao.StudentDao;
import com.bdqn.util.Student;

/**
 * ʵ����
 * @author ��ҫ��
 *
 * 2018��1��10������5:02:14
 */
public class StudentDaoImpl implements StudentDao{
	Student st=new Student();
	Connection con=st.Lei_0();
	@Override
	/**
	 * ʵ����
	 */
	public int add(StudentBean sb) {
		String sql="insert into student values (sid,?,?,?,?);";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,sb.getSname());
			ps.setString(2,sb.getSsex());
			ps.setInt(3,sb.getAsge());
			ps.setInt(4,sb.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	@Override
	/**
	 * ʵ��ɾ
	 */
	public int del(int t) {
		String sql="delete from student where sid='"+t+"';";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	@Override
	/**
	 * ʵ�ָ�
	 */
	public int upd(StudentBean stb) {
		String sql="update student set sname=?,ssex=?,asge=?,gid=? where sid=?;";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,stb.getSname());
			ps.setString(2,stb.getSsex());
			ps.setInt(3,stb.getAsge());
			ps.setInt(4,stb.getGid());
			ps.setInt(5,stb.getSid());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	@Override
	/**
	 * ��ʵ��
	 */
	public List<StudentBean> sel() {
		String sql="select * from student";
		List<StudentBean> list=new ArrayList<StudentBean>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				StudentBean stb=new StudentBean();
				stb.setSid(rs.getInt("sid"));
				stb.setSname(rs.getString("sname"));
				stb.setSsex(rs.getString("ssex"));
				stb.setAsge(rs.getInt("asge"));
				stb.setGid(rs.getInt("gid"));
				list.add(stb);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

}
