package com.bdqn.dao;

import java.util.List;

import com.bdqn.bean.StudentBean;

/**
 * �ӿڰ�
 * @author ��ҫ��
 *
 * 2018��1��10������4:55:40
 */
public interface StudentDao {
	/**
	 * ��
	 * @return
	 */
	public int add(StudentBean sb);
	/**
	 * ɾ
	 * @return
	 */
	public int del(int t);
	/**
	 * ��
	 * @return
	 */
	public int upd(StudentBean stb);
	/**
	 * ��
	 * @return
	 */
	public List<StudentBean> sel();
}
