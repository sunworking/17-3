package com.bdqn.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * �����ݿ����Ӱ�
 * @author ��ҫ��
 *
 * 2018��1��10������4:51:50
 */
public class Student {
	private final String NAME="root";
	private final String MM="root";
	private final String DZ="jdbc:mysql://localhost:3306/yyq";
	private final String DRIVER="com.mysql.jdbc.Driver";
	public Connection Lei_0(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(DZ, NAME, MM);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
}

