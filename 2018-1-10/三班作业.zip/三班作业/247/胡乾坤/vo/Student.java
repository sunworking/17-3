package com.bdqn.vo;

public class Student {
	private int sid;
	private String sname;
	private String ssex;
	private String asge;
	private String gid;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSsex() {
		return ssex;
	}
	public void setSsex(String ssex) {
		this.ssex = ssex;
	}
	public String getAsge() {
		return asge;
	}
	public void setAsge(String asge) {
		this.asge = asge;
	}
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
}
