package com.bdqn.text;

import com.bdqn.dao.StudentDao;	
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

/**
 * 
 * @author ��Ǭ��
 *
 * 2018��1��10������9:08:35
 */
public class Text {
	public static void main(String[] args) {
	StudentDao sd=new StudentDaoImpl();
	Student ss=new Student();
	ss.setSname("����");
	ss.setSsex("��");
	ss.setAsge("18");
	ss.setGid("1002");
	int i=sd.addStudent(ss);	
}
}