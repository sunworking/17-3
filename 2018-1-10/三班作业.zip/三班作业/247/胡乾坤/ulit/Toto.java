package com.bdqn.ulit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 
 * @author ��Ǭ��
 *
 * 2018��1��10������8:12:53
 */
public class Toto {
	private final String NAME="root";
	private final String POW="root";
	private final String URL="jdbc:mysql://localhost:3306/text";
	private final String DRIVER="com.mysql.jdbc.Driver";
	
	public Connection todb(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(URL,NAME,POW);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
}





