package com.bdqn.dao.impl;

import java.sql.Connection;	
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.dao.StudentDao;
import com.bdqn.ulit.Toto;
import com.bdqn.vo.Student;
/**
 * 
 * @author ��Ǭ��
 *
 * 2018��1��10������8:55:35
 * @param <Toto>
 */
public  class StudentDaoImpl implements StudentDao{
	 Toto t=new Toto();
	 Connection con= t.todb();
	@Override
	public int addStudent(Student s) {
		String sql="insert into Student values(sid,?,?,?)";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(1, s.getSsex());
			ps.setString(1, s.getAsge());
			ps.setString(1, s.getGid());
			i=(int) ps.executeLargeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
		@Override
	public int delStudent(int s) {
		String sql="delete from Student where snane='asd'";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}

	@Override
	public int updateStudent(Student s) {
		String sql="update Student set sname='?',ssex='?',asge='?'gid='?' where sid='?'";
		int i=0;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(1, s.getSsex());
			ps.setString(1, s.getAsge());
			ps.setString(1, s.getGid());
			i=(int) ps.executeLargeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}



	public List<Student> query(){
		String sql="select * from Student where 1=1";
		List<Student> list=new ArrayList<Student>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet sr=ps.executeQuery();
			while (sr.next()) {
				Student s=new Student();
				s.setSname(((ResultSet) ps).getString("sname"));
				s.setSsex(((ResultSet) ps).getString("ssex"));
				s.setAsge(((ResultSet) ps).getString("asge"));
				s.setGid( ((ResultSet) ps).getString("gid"));
				list.add(s);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return null;	
	}
	
}
