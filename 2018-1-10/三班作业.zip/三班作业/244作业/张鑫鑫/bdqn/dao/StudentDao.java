package com.bdqn.dao;

import java.util.List;

import com.bdqn.bean.Student;

/**
 * ��  ɾ  �� ��
 * @author ������
 *2018-1-10����9:09:07
 *
 */
public interface StudentDao {
	public  int   addStudent(Student s);
	public  int   delStudent(Student s);
	public  int   updateStudent(Student s);
	public  List<Student> queryallStudent();


}
