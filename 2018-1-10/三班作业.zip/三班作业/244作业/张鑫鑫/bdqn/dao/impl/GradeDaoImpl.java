package com.bdqn.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.bean.Grade;
import com.bdqn.bean.Student;
import com.bdqn.dao.GradeDao;
import com.bdqn.util.Todb;

/**
 * ʵ�ֽӿ�
 * @author ������
 *
 * 2018��1��10������12:48:09
 */
public class GradeDaoImpl implements  GradeDao {
	/**
	 * ��������
	 */
	 Todb t=new Todb();
     Connection con=t.todb();
	
	/**
	 * ���ǰ༶���� ��
	 */
	public int addGrade(Grade g) {
		int  i=0;
		String  sql="insert into grade  values( did, gname=?,teacher=? )";
		try {
			PreparedStatement   ps=con.prepareStatement(sql);
			ps.setString(1, g.getGname());
			ps.setString(2, g.getTeacher());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	/**
	 * ���ǰ༶����ɾ
	 */
	public int delGrade(Grade g) {
		int i=0;
		String   sql="delete from grade where  did=? ";
		
		try {
			PreparedStatement	 ps=con.prepareStatement(sql);
			ps.setInt(1, g.getDid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	/**
	 * ���ǰ༶���� ��
	 */
	public int updateGrade(Grade g) {
		int i=0;
		String  sql="update grade  set   gname=?,  teacher=?  where did=? ";
		try {
			PreparedStatement    ps=con.prepareStatement(sql);
			ps.setString(1, g.getGname());
			ps.setString(2, g.getTeacher());
			ps.setInt(3, g.getDid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	/**
	 * ���ǰ༶���� ��
	 */
	public List<Grade> queryallGrade() {
		String  sql="select  gname   from grade ";
		List<Grade>  list=new ArrayList<Grade>();
		   try {
			   PreparedStatement    ps=con.prepareStatement(sql);
			   ResultSet   rs= ps.executeQuery();
			   while(rs.next()){
				   Grade   g=new  Grade();
				   g.setDid(rs.getInt("did"));
				   g.setGname(rs.getString("gname"));
				   g.setTeacher(rs.getString("teacher"));
				   list.add(g);
			   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return list;
	}
}
