package com.bdqn.test;

import java.util.List;

import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;
import com.bdqn.vo.Student;

/**
 * 
 * @author ��־��
 *
 *2018��1��10������8:59:30
 */
public class StudentTest {
	public static void main(String[] args) {
		Student s=new Student();
		StudentDao sd=new StudentDaoImpl();
		/**��
		 * s.setSname("����");
		s.setSsex("��");
		s.setSage(20);
		s.setGid(3);
		sd.add(s);*/
		/**ɾ
		 * sd.del(2);*/
		/**��
		 * s.setSname("����");
		s.setSsex("��");
		s.setSage(20);
		s.setGid(3);
		s.setSid(1);
		int i=sd.update(s);*/
		List<Student> list=sd.sel();
		for(Student student:list){
			System.out.println(student.getSid()+student.getSname()+student.getSsex()+student.getSage()+student.getGid());
		}
		

		
	}
	

}
