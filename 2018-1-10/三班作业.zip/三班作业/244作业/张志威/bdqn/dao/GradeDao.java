package com.bdqn.studentdao;

import java.util.List;

import com.bdqn.vo.Grade;
/**
 * 
 * @author��־��
 *
 * 2018��1��10������9:29:27
 */
public interface GradeDao {
	public int add(Grade g);
	public int del(int i);
	public int update(Grade g);
	public List<Grade> query();

}
