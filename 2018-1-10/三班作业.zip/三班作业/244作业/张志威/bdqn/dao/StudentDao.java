package com.bdqn.studentdao;

import java.util.List;

import com.bdqn.vo.Student;

/**
 * 
 * @author ��־��
 *
 *2018��1��10������8:54:32
 */
public interface StudentDao {
	public int add(Student s);
	public int del(int sid);
	public int update(Student s);
	public List<Student> sel();

}
