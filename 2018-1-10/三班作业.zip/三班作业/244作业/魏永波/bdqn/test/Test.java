package com.bdqn.test;

import java.util.List;

import com.bdqn.bean.Student;
import com.bdqn.dao.StudentDao;
import com.bdqn.dao.impl.StudentDaoImpl;

/**
 * 
 * @author κ����
 *
 * 2018��1��10������10:26:50
 */
public class Test {
	public static void main(String[] args) {
	//	StudentDao   sd=new  StudentDaoImpl();
	//	Student  s=new   Student();
//		s.setSname("����");
//		s.setSsex("��");
//		s.setAsge(20);
//		s.setGid(2);
//	   int	 i=sd.addStudent(s);
//	if(i==1){
//		System.out.println("�����ɹ�");
//	}else{
//		System.out.println("����ʧ��");
//	}
//		s.setSid(3);
//		int i=sd.delStudent(s);
//		if(i==1){
//			System.out.println("�����ɹ�");
//		}else{
//			System.out.println("����ʧ��");
//		}
//	   s.setSname("�μѱ�");
//	   s.setSsex("Ů");
//	   s.setAsge(22);
//	   s.setGid(1);
//	   s.setSid(5);
//	   int i=sd.updateStudent(s);
//	   if(i==1){
//			System.out.println("�����ɹ�");
//		}else{
//			System.out.println("����ʧ��");
//		}
		StudentDaoImpl      s=new  StudentDaoImpl();
		List<Student> list=s.queryallStudent();
		for (Student student : list) {
			System.out.println(student.getSname()+student.getAsge());
		}
		
	}
}
