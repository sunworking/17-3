package com.bdqn.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * 
 * @author κ����
 *2018-1-10����8:24:23
 *
 */
public class Todb {
	private  final String  MAVE="root";//�û���
	private final String  PWD="root";//����
	private final String    URL="jdbc:mysql://localhost:3306/test";//��������
	private final  String    DRIVER="com.mysql.jdbc.Driver";//����������
	public  Connection todb(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(URL, MAVE, PWD);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}public static void main(String[] args) {
		//����
		Todb  t=new   Todb();
		Connection   con=t.todb();
		System.out.println(con);
	}
}