package com.bdqn.studentdao;

import java.util.List;

import com.bdqn.vo.Student;
/**
 * 
 * @author����
 *
 * 2018��1��10������9:33:42
 */
public interface StudentDao {
	public int add(Student s);
	public int del(int i);
	public int update(Student s);
	public List<Student> cha();

}
