package com.bdqn.until;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * 
 * @author����
 *
 * 2018��1��10������9:33:34
 */
public class Until {
	private final String NAME="root";
	private final String PwD="root";
	private final String URL="jdbc:mysql://localhost:3306/test";
	private final String DRIVER="com.mysql.jdbc.Driver";
	public Connection until(){
		Connection con=null;
		try {
			Class.forName(DRIVER);
			con=DriverManager.getConnection(URL, NAME, PwD);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

}
