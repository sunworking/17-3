package com.bdqn.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.studentdao.Gradedao;
import com.bdqn.until.Until;
import com.bdqn.vo.Grade;

/**
 * 
 * @author����
 *
 * 2018��1��10������9:33:23
 */
public class Gradeimpl implements Gradedao{
	Until u=new Until();
	Connection con=u.until();

	@Override
	public int add(Grade g) {
		int i=0;
		String sql="insert into grade values(did,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, g.getGname());
			ps.setString(2, g.getTeacher());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
		
	}

	@Override
	public int del(int did) {
		int i=0;
		String sql="delete from grade where did="+did;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}

	@Override
	public int update(Grade g) {
		int i=0;
		String sql="update grade set gname=?,teacher=? where did=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, g.getGname());
			ps.setString(2, g.getTeacher());
			ps.setInt(3, g.getDid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}

	@Override
	public List<Grade> query() {
		String sql="select*from grade";
		List<Grade> list =new ArrayList<Grade>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();//ִ�в�ѯ���õ�һ�������
			while(rs.next()){		//�жϽ�������Ƿ�����һ������ ����� �α�λ���ƶ�������true
				Grade ee=new Grade();
				ee.setDid(rs.getInt("did"));
				ee.setGname(rs.getString("gname"));
				ee.setTeacher(rs.getString("teacher"));
				list.add(ee);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}

}
