package com.bdqn.student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bdqn.studentdao.StudentDao;
import com.bdqn.until.Until;
import com.bdqn.vo.Student;
/**
 * 
 * @author����
 *
 * 2018��1��10������9:33:08
 */
public class Studentimpl implements StudentDao {
	Until u=new Until();
	Connection con=u.until();

	@Override
	public int add(Student s) {
		int i=0;
		String sql="insert into student values(sid,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAge());
			ps.setString(4, s.getGid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
	}

	@Override
	public int del(int sid) {
		int i=0;
		String sql="delete from student where sid="+sid;
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int update(Student s) {
		int i=0;
		String sql="update student set sname=?,ssex=?,age=?,gid=? where sid=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, s.getSname());
			ps.setString(2, s.getSsex());
			ps.setInt(3, s.getAge());
			ps.setString(4, s.getGid());
			ps.setInt(5, s.getSid());
			i=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<Student> cha() {
		String sql="select*from student";
		List<Student> list =new ArrayList<Student>();
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();//ִ�в�ѯ���õ�һ�������
			while(rs.next()){		//�жϽ�������Ƿ�����һ������ ����� �α�λ���ƶ�������true
				Student st=new Student();
				st.setSid(rs.getInt("sid"));
				st.setSname(rs.getString("sname"));
				st.setSsex(rs.getString("ssex"));
				st.setAge(rs.getInt("age"));
				st.setGid(rs.getString("gid"));
				list.add(st);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
		
	}

}
