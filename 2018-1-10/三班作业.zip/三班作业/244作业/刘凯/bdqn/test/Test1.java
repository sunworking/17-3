package com.bdqn.test;

import java.util.List;

import com.bdqn.student.Gradeimpl;
import com.bdqn.student.Studentimpl;
import com.bdqn.studentdao.Gradedao;
import com.bdqn.studentdao.StudentDao;
import com.bdqn.vo.Grade;
import com.bdqn.vo.Student;
/**
 * 
 * @author����
 *
 * 2018��1��10������9:33:16
 */
public class Test1 {
	public static void main(String[] args) {
		Grade e=new Grade();
		Gradedao gd=new Gradeimpl();
		/*e.setGname("С����һ��");
		e.setTeacher("����̫");	��
		gd.add(e);*/
		//gd.del(1);		ɾ
		/*e.setGname("С�ܲ�һ��");
		e.setTeacher("������");
		e.setDid(3);		��
		gd.update(e);*/
		List<Grade> list=gd.query();
		for(Grade grade:list){
			System.out.println(grade.getDid()+grade.getGname()+grade.getTeacher());
		}
		
	}

}
